Change Log
==========

Version 0.5.1 *(2016-01-03)*
----------------------------

 * Fix: calling the `displayLoadingRow(true|false)`upon AbsListView `WrapperAdapter` will now call
 `notifyDataSetChanged` if needed.

Version 0.5.0 *(2015-11-07)*
----------------------------

 * Initial public release