package com.example.paginate.adapter;

import android.view.View;

public interface RecyclerOnItemClickListener {
    void onItemClicked(View view, int position);
}